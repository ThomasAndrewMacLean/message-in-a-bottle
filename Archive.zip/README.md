# message-in-a-bottle

## docs

### setup

[babel](https://www.robinwieruch.de/minimal-node-js-babel-setup/)
[postgres](https://www.robinwieruch.de/postgres-express-setup-tutorial/)

[CD travis official docs](https://docs.travis-ci.com/user/deployment/elasticbeanstalk/)

[CD travis medium article](https://medium.com/@sommershurbaji/continuous-delivery-with-aws-elastic-beanstalk-and-travis-ci-2dd54754965f)

[environment variables EB](https://alexdisler.com/2016/03/26/nodejs-environment-variables-elastic-beanstalk-aws/)

[Ajax form](https://blog.teamtreehouse.com/create-ajax-contact-form)

### consoles

[postgres](https://api.elephantsql.com)
[aws EB](https://eu-west-1.console.aws.amazon.com/elasticbeanstalk)
